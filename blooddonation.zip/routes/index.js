const userRoute = require('./userRoute');
const donateBloodRoute=require('./donateBloodRoute')
const createRequestRoute=require('./createRequestRoute')
const ratingRoute=require('./ratingRoute')


module.exports = {
    userRoute,
    donateBloodRoute,createRequestRoute,ratingRoute
};
